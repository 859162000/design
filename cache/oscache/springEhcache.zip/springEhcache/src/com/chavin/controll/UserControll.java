package com.chavin.controll;

import com.chavin.service.UserService;
import com.chavin.vo.User;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping({ "/user" })
public class UserControll {

	@Autowired
	private UserService userService;

	@RequestMapping({ "getUserList" })
	public ModelAndView getUserList() {
		ModelAndView modelAndView = new ModelAndView();
		List<User> userList = this.userService.getAll();
		modelAndView.setViewName("index");
		modelAndView.addObject("userList", userList);
		return modelAndView;
	}

	@RequestMapping({ "update" })
	@ResponseBody
	public int update(HttpServletRequest request, HttpServletResponse response, @RequestParam Integer deleted, @RequestParam String condition) {
		if ((deleted == null) || (condition == null) || (condition == ""))
			return 0;
		int m = this.userService.updateUser(deleted.intValue(), condition);
		return m;
	}

	@RequestMapping({ "/clear" })
	@ResponseBody
	public String clear() {
		userService.removeAll();
		return "success";
	}
}