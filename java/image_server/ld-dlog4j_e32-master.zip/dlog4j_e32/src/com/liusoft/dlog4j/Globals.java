/*
 *  Globals.java
 *  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 *  Author: Winter Lau
 *  http://dlog4j.sourceforge.net
 *  
 */
package com.liusoft.dlog4j;

import java.util.Comparator;
import java.util.Random;

import com.liusoft.dlog4j.base._BeanBase;

/**
 * DLOG4J��ȫ�ֳ�������
 * @author Winter Lau
 */
public class Globals {

	public final static String DEFAULT_CONTENT_TYPE = "text/html;charset=UTF-8";
	
	public final static String LOCAL_PATH_PREFIX = "file://";
	
	public final static String ENC_UTF_8 = "UTF-8";
	public final static String ENC_8859_1 = "8859_1";

	public final static String RANDOM_LOGIN_KEY = "RANDOM_LOGIN_KEY";
	
	public final static String PARAM_SID = "sid";
	
	public final static String MAIL_QUEUE = "MAIL_QUEUE";

	public final static String USER_AGENT = "user-agent";
	
	public final static String SESSION_ID_KEY_IN_COOKIE = "DLOG_SESSION_ID";
	
	public final static String ALBUM_VERIFY_KEY = "ALBUM_";
	
	/**
	 * ���й�����webapp���ڵ�·��
	 * ��DLOG_ActionServlet���и�ֵ
	 * @see com.liusoft.dlog4j.servlet.DLOG_ActionServlet#init()
	 */
	public static String WEBAPP_PATH ;

	/**
	 * �����������
	 */
	public final static Comparator<_BeanBase> random_comparator = new Comparator<_BeanBase>(){
		Random random_gen = new Random(System.currentTimeMillis());
		public int compare(_BeanBase bean0, _BeanBase bean1) {
			int r1 = random_gen.nextInt(50);
			int r2 = random_gen.nextInt(50);
			return r1 - r2;
		}		
	};
	
}
