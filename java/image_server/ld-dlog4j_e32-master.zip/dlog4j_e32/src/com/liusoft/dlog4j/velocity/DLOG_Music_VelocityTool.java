/*
 *  DLOG_Music_VelocityTool.java
 *  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 *  Author: Winter Lau (javayou@gmail.com)
 *  http://dlog4j.sourceforge.net
 */
package com.liusoft.dlog4j.velocity;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.liusoft.dlog4j.base._BeanBase;
import com.liusoft.dlog4j.beans.MusicBean;
import com.liusoft.dlog4j.beans.MusicBoxBean;
import com.liusoft.dlog4j.beans.SiteBean;
import com.liusoft.dlog4j.dao.MusicDAO;

/**
 * ����Ƶ����Velocity toolbox��
 * @author Winter Lau
 */
public class DLOG_Music_VelocityTool{

	private final static Log log = LogFactory.getLog(DLOG_Music_VelocityTool.class);
	
	/**
	 * ��¼�������ʹ���
	 * @param songs
	 */
	public void visit_music(List songs){
		if(songs!=null && songs.size()>0){
			int[] ids = new int[songs.size()];
			for(int i=0;i<songs.size();i++){
				_BeanBase bean = (_BeanBase)songs.get(i);
				ids[i] = bean.getId();
			}
			try{
				MusicDAO.incViewCount(1, ids);
			}catch(Exception e){
				log.error("increment music's listen count failed.", e);
			}
		}
	}
	
	/**
	 * ��ȡ���ֺ���Ϣ
	 * @param mboxid
	 * @return
	 */
	public MusicBoxBean box(int mboxid){
		if(mboxid < 1)
			return null;
		return MusicDAO.getMusicBoxByID(mboxid);
	}
	
	/**
	 * ��ѯ�����в���ĳ�����ֺеĸ���
	 * @param site_id
	 * @return
	 */
	public List songs_without_box(SiteBean site){
		if(site == null)
			return null;
		return MusicDAO.listSongsWithoutBox(site.getId());
	}
	
	/**
	 * ��ȡ������ϸ��Ϣ
	 * @param music_id
	 * @return
	 */
	public MusicBean music(int music_id){
		if(music_id < 1)
			return null;
		return MusicDAO.getMusicByID(music_id);		
	}

	/**
	 * ��ȡ������
	 * @param site
	 * @return
	 */
	public int music_count(SiteBean site){
		if(site == null)
			return -1;
		return MusicDAO.getMusicCount(site);
	}
	
	public int all_music_count(){
		return MusicDAO.getAllMusicCount();
	}
	
	public List list_all_music(int page,int count){
		int fromIdx = (page-1)*count;
		return MusicDAO.listAllMusics(fromIdx, count);
	}
	
	/**
	 * �г�ѡ�еĸ�����Ϣ
	 * @param mids
	 * @return
	 */
	public List list_songs(String mids){
		if(mids == null)
			return null;
		StringTokenizer st = new StringTokenizer(mids,",");
		List<Integer> ids = new ArrayList<Integer>();
		while(st.hasMoreElements()){
			String sid = st.nextToken();
			try{
				ids.add(Integer.parseInt(sid));
			}catch(Exception e){}
		}
		return MusicDAO.listSongs(ids);
	}
	
	/**
	 * �г�ĳ��վ�����µĸ���
	 * @param site
	 * @return
	 */
	public List list_new_songs(SiteBean site, int max_count){
		return list_new_songs(site, -1, max_count);
	}

	/**
	 * �г�ĳ��վ�����µĸ���
	 * @param site
	 * @return
	 */
	public List list_new_songs(SiteBean site, int page, int count){
		if(site==null)
			return null;
		int from_idx = -1;
		if(page>0 && count>0)
			from_idx = (page - 1) * count;
		return MusicDAO.listNewSongs(site.getId(), from_idx, count);
	}
	
	public List list_songs(SiteBean site, MusicBoxBean box, int page, int count){
		if(site==null)
			return null;
		int from_idx = -1;
		if(page>0 && count>0)
			from_idx = (page - 1) * count;
		int boxid = (box!=null)?box.getId():-1;
		return MusicDAO.listNewSongs(site.getId(), boxid, from_idx, count);
	}
	
	public int get_song_count(SiteBean site, MusicBoxBean box){
		if(site==null)
			return -1;
		int boxid = (box!=null)?box.getId():-1;
		return MusicDAO.getSongCount(site.getId(), boxid);
	}
	
}
