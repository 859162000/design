package com.djk.springdemo.mapper;

import com.djk.springdemo.bean.Email;
public interface TestMapper {
	Email findemail();
}
