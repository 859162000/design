package com.enation.framework.util.ip;

public class IPEntry {
	    public String beginIp;  
	    public String endIp;  
	    public String country;  
	    public String area;  
	      
	    /** 
	     * 构造函数 
	     */  
	    public IPEntry() {  
	        beginIp = endIp = country = area = "";  
	    }  
}
