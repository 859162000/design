/**
 * <a href="http://www.xmlrpc.com/metaWeblogApi">MetaWeblog API</a> requests 
 * processing.
 */
package org.b3log.solo.api.metaweblog;
