package com.enation.eop.resource.model;

/**
 * 挂件束
 * 
 * @author kingapex<br/>
 *         <b>Edited by lzf 2009-11-18</b>
 * 
 */
public class WidgetBundle extends Resource {

	private String widgetname;
	private String widgettype;
	private String settingurl;

	public String getWidgetname() {
		return widgetname;
	}

	public void setWidgetname(String widgetname) {
		this.widgetname = widgetname;
	}

	public String getWidgettype() {
		return widgettype;
	}

	public void setWidgettype(String widgettype) {
		this.widgettype = widgettype;
	}

	public String getSettingurl() {
		return settingurl;
	}

	public void setSettingurl(String settingurl) {
		this.settingurl = settingurl;
	}

}
