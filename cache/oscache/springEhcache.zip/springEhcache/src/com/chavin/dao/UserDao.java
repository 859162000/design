package com.chavin.dao;

import com.chavin.vo.User;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;

@Repository
public class UserDao {

	public List<User> findAll() {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		List userList = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/cache";
			conn = DriverManager.getConnection(url, "root", "root");
			String sql = "select * from user";
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();

			userList = new ArrayList();
			while (rs.next()) {
				User user = new User();
				user.setId(Integer.valueOf(rs.getInt(1)));
				user.setName(rs.getString(2));
				user.setAge(Integer.valueOf(rs.getInt(3)));
				user.setSex(rs.getString(4));
				user.setAddress(rs.getString(5));
				user.setDeleted(Integer.valueOf(rs.getInt(6)));
				userList.add(user);
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			CloseAll(pst, conn, rs);
		}
		return userList;
	}

	public int updateUser(int deleted, String sql) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		List userList = null;
		int m = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/cache";
			conn = DriverManager.getConnection(url, "root", "root");
			pst = conn.prepareStatement("update user set deleted = ? where "
					+ sql);
			pst.setInt(1, deleted);
			m = pst.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			CloseAll(pst, conn, rs);
		}
		return m;
	}

	private static void CloseAll(PreparedStatement pst, Connection connection,
			ResultSet rs) {
		try {
			if (rs != null) {
				rs.close();
			}
			if (pst != null) {
				pst.close();
			}
			if (connection != null)
				connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}