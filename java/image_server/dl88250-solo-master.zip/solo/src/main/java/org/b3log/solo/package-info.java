/**
 * <a href="https://github.com/b3log/solo">Solo</a>.
 */
package org.b3log.solo;
