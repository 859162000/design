package com.enation.app.base.core.plugin.express;

import com.enation.app.base.core.model.ExpressPlatform;

public class AbstractExpressComponent {
	
	public static void addExpress(ExpressPlatform expressPlatform){
		
	}

}
