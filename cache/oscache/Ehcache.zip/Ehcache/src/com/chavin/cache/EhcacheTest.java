package com.chavin.cache;

import java.net.URL;
import java.util.List;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

public class EhcacheTest {

	public static void main(String[] args) {
		test1();
		//test2();
		//test3();
	}

	public static void test1() {
		URL url = EhcacheTest.class.getClass().getResource("/ehcache.xml");

		// classpath找寻配置文件并创建
		CacheManager cacheManager = CacheManager.create(url);

		Cache cache;
		// 取出所有的cacheName
		String names[] = cacheManager.getCacheNames();
		for (int i = 0; i < names.length; i++) {
			// 获取配置中的Cache
			cache = cacheManager.getCache(names[i]);
			System.out.println(cache.toString());
		}

		cache = cacheManager.getCache("simpleCache");
		System.out.println(cache.getKeys().toString());
		
		Element element = new Element("key", "123456");
		cache.put(element);
		Element element2 = new Element("key2", "123456123123");
		cache.put(element2);

		System.out.println(cacheManager.getCache("simpleCache").get("key2").getObjectValue());
		cacheManager.shutdown();
	}

	public static void test2(){
		EhcacheUtil ehcacheUtil = EhcacheUtil.getInstance();
		ehcacheUtil.putElement("cache", "name", "张三");
		ehcacheUtil.putElement("cache", "age", "15");
		System.out.println(ehcacheUtil.getElement("cache", "name").toString());
		
	}
	
	public static void test3(){
		URL url = EhcacheTest.class.getClass().getResource("/ehcache.xml");

		// classpath找寻配置文件并创建
		CacheManager cacheManager = CacheManager.create(url);
		Cache cache = new Cache("test", 1, true, false, 5, 2);     
		cacheManager.addCache(cache);
		Cache ch = cacheManager.getCache("test");
		String[] names = cacheManager.getCacheNames();
		for(int i = 0 ; i < names.length; i++){
			Cache cache2 = cacheManager.getCache(names[i]);
			System.out.println(cache2.getName());
		}
		cacheManager.shutdown();
	}
}
