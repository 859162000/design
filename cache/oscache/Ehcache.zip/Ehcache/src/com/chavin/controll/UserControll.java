package com.chavin.controll;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.chavin.cache.EhcacheUtil;
import com.chavin.dao.UserDao;
import com.chavin.vo.User;

@RequestMapping(value="/user")
@Controller
public class UserControll {

	@RequestMapping(value="/getUserList")
	public ModelAndView getUserList(){
		ModelAndView modelAndView = new ModelAndView();
		EhcacheUtil uEhcacheUtil = EhcacheUtil.getInstance();
		List<User> userList = (List<User>) uEhcacheUtil.getElement("userListCache", "userList");
		String cacheInfo = "";
		if(userList == null || userList.size() == 0){
			cacheInfo = "缓存中无值，本数据是从数据库中获取";
			UserDao dao = new UserDao();
			userList = dao.getUserList();
		}else{
			cacheInfo = "缓存中有值，从缓存userListCache中直接获取本次数据";
		}
		modelAndView.setViewName("index");
		modelAndView.addObject("userList", userList);
		modelAndView.addObject("cacheInfo", cacheInfo);
		return modelAndView;
	}
	
	@RequestMapping(value="update")
	@ResponseBody
	public int update(HttpServletRequest request, HttpServletResponse response,@RequestParam Integer deleted ,@RequestParam String condition){
		if(deleted == null || condition == null || condition == "")
			return 0;
		UserDao dao = new UserDao();
		int m = dao.update(deleted, condition);
		return m;
	}
}
