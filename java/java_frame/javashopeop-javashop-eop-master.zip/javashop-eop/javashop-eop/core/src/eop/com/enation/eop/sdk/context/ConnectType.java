package com.enation.eop.sdk.context;

public interface ConnectType {
	public static final int remote=1;
	public static final int local=0;
}
