package com.enation.framework.component;


/**
 * 组件可起动接口
 * @author kingapex
 *2015-5-15
 */
public interface IComponentStartAble {
	
	
	public void start();
	
	
	
	
}
