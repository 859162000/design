package com.enation.eop.processor.core;

public class UrlNotFoundException extends RuntimeException {

}
