package com.chavin.memcached;

import java.io.IOException;
import java.net.InetSocketAddress;

import com.chavin.vo.User;

import net.spy.memcached.MemcachedClient;

public class TestMemcached {

	public static void main(String[] args) throws IOException {
		MemcachedClient cache = new MemcachedClient(new InetSocketAddress("127.0.0.1", 11211));
		for (int i = 1; i < 10; i++) {  
            cache.set("T" + i, 3600, new User(i,"张三" + i));   
        }
        User myObject = (User) cache.get("T1");  
        System.out.println("从内存中获取缓存 :" + myObject.toString());   
        System.out.println(cache.get("hello"));
        cache.shutdown();
    }   
}
