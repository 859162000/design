package com.chavin.listener;

import java.util.Iterator;
import java.util.List;

import com.chavin.vo.User;

import net.sf.ehcache.CacheException;
import net.sf.ehcache.Ehcache;
import net.sf.ehcache.Element;
import net.sf.ehcache.event.CacheEventListener;

/**
 * 监听当Element的值为null时则清除改缓存
 * 
 * CustomCacheEventListener
 * 时间：2015年12月4日-下午3:48:58 
 * @version 1.0.0
 *
 */
public class CustomCacheEventListener implements CacheEventListener {

	@Override
	public void dispose() {
		System.out.println("自定义ehcache监听器进入方法dispose");
	}

	@Override
	public void notifyElementEvicted(Ehcache cache, Element element) {
		System.out.println("自定义ehcache监听器进入方法notifyElementEvicted");
	}

	@Override
	public void notifyElementExpired(Ehcache cache, Element element) {
		System.out.println("自定义ehcache监听器进入方法notifyElementExpired");
	}

	@Override
	public void notifyElementPut(Ehcache cache, Element element) throws CacheException {
		removeIfNull(cache, element);
		System.out.println("自定义ehcache监听器进入方法notifyElementPut");
	}

	@Override
	public void notifyElementRemoved(Ehcache cache, Element element) throws CacheException {
		System.out.println("自定义ehcache监听器进入方法notifyElementRemoved");
	}

	@Override
	public void notifyElementUpdated(Ehcache cache, Element element) throws CacheException {
		removeIfNull(cache, element); 
		System.out.println("自定义ehcache监听器进入方法notifyElementUpdated");
	}

	@Override
	public void notifyRemoveAll(Ehcache cache) {
		System.out.println("自定义ehcache监听器进入方法notifyRemoveAll");
	}
	
	public Object clone() throws CloneNotSupportedException { 
        return null;  //To change body of implemented methods use File | Settings | File Templates. 
	}
	
	private void removeIfNull(final Ehcache cache, final Element element) {  
		System.out.println("自定义ehcache监听器进入自定义方法removeIfNull");
        /*if (element.getObjectValue() == null) {  
            cache.remove(element.getKey());
        }  */
		/*List<User> users = (List<User>) element.getObjectValue();
		Iterator<User> iterator = users.iterator();
		while(iterator.hasNext()){
			if(iterator.next() == null){
				iterator.remove();
			}
		}*/
    }  
}
