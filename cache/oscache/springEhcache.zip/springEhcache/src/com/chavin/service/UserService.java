package com.chavin.service;

import com.chavin.dao.UserDao;
import com.chavin.vo.User;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class UserService {
	
	private UserDao userDao;
	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	@Autowired
	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	//@Cacheable({ "serviceCache" })指定缓存名为serviceCache，如果后面有参数可以指定key=#p0作为参数
	@Cacheable({ "serviceCache" })
	public List<User> getAll() {
		System.out.println(sdf.format(new Date()) + ": 本次查询getAll()数据从数据库中获取");
		List users = this.userDao.findAll();
		return users;
	}

	@CacheEvict(value = { "serviceCache" }, allEntries = true)
	public int updateUser(int deleted, String sql) {
		System.out.println("执行updateUser方法，缓存已清空");
		return this.userDao.updateUser(deleted, sql);
	}

	//@CacheEvict用于清除缓存，beforeInvocation为在方法执行前清除
	@CacheEvict(value = { "serviceCache" }, allEntries = true, beforeInvocation = true)
	public void removeAll() {
		System.out.println("清除所有缓存");
	}
}