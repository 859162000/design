/**
 * Keys.
 */
package org.b3log.solo.model;
