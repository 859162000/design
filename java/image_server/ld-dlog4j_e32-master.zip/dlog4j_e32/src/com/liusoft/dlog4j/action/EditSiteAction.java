/*
 *  EditSiteAction.java
 *  
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *  
 *  Author: Winter Lau
 *  http://dlog4j.sourceforge.net
 *  
 */
package com.liusoft.dlog4j.action;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.liusoft.dlog4j.DLOGSecurityManager;
import com.liusoft.dlog4j.SessionUserObject;
import com.liusoft.dlog4j.base.FunctionStatus;
import com.liusoft.dlog4j.beans.SiteBean;
import com.liusoft.dlog4j.beans.UserBean;
import com.liusoft.dlog4j.dao.AdminDAO;
import com.liusoft.dlog4j.dao.SiteDAO;
import com.liusoft.dlog4j.formbean.SiteForm;
import com.liusoft.dlog4j.util.StringUtils;

/**
 * վ���޸���վ��Ϣ�Ĳ���
 * 
 * @author Winter Lau
 */
public class EditSiteAction extends AdminActionBase {

	/**
	 * �޸���վ��������
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 * @wml_only mgr/modify_name.vm
	 */
	protected ActionForward doUpdateFriendlyName(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		SiteForm sform = (SiteForm) form;
		super.validateClientId(request, sform);
		ActionMessages msgs = new ActionMessages();

		while (StringUtils.isNotEmpty(sform.getFriendlyName())) {
			SiteBean site = super.getSiteBean(request);
			String fn = super.autoFiltrate(site, sform.getFriendlyName());
			if (!StringUtils.equals(site.getFriendlyName(), fn)) {
				// �����վ���Ƿ��Ѿ�����
				if (SiteDAO.getSiteByFriendlyName(fn) != null) {
					msgs.add("friendlyName", new ActionMessage(
							"error.site_friendlyName_exists"));
					break;
				}
				try {
					site.setFriendlyName(fn);
					SiteDAO.flush();
				} catch (Exception e) {
					msgs.add("result", new ActionMessage("error.database", e
							.getMessage()));
				}
			}
			break;
		}

		if (!msgs.isEmpty()) {
			saveMessages(request, msgs);
			return mapping.findForward("modify_name");
		}

		return makeForward(mapping.findForward("editsite"), sform.getSid());
	}

	/**
	 * �޸���վ������
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 * @wml_only mgr/modify_detail.vm
	 */
	protected ActionForward doUpdateDetail(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		SiteForm sform = (SiteForm) form;
		super.validateClientId(request, sform);
		ActionMessages msgs = new ActionMessages();

		do {
			SiteBean site = super.getSiteBean(request);
			String detail = super.autoFiltrate(site, StringUtils
					.extractText(sform.getDetail()));
			if (!StringUtils.equals(site.getDetail(), detail)) {
				try {
					site.setDetail(detail);
					SiteDAO.flush();
				} catch (Exception e) {
					msgs.add("result", new ActionMessage("error.database", e
							.getMessage()));
				}
			}
			break;
		} while (true);

		if (!msgs.isEmpty()) {
			saveMessages(request, msgs);
			return mapping.findForward("modify_detail");
		}

		return makeForward(mapping.findForward("editsite"), sform.getSid());
	}

	/**
	 * �޸���վ�ı���
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 * @wml_only mgr/modify_title.vm
	 */
	protected ActionForward doUpdateTitle(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		SiteForm sform = (SiteForm) form;
		super.validateClientId(request, sform);
		ActionMessages msgs = new ActionMessages();

		do {
			SiteBean site = super.getSiteBean(request);
			String title = super.autoFiltrate(site, sform.getTitle());
			if (!StringUtils.equals(site.getTitle(), title)) {
				try {
					site.setTitle(title);
					SiteDAO.flush();
				} catch (Exception e) {
					msgs.add("result", new ActionMessage("error.database", e
							.getMessage()));
				}
			}
			break;
		} while (true);

		if (!msgs.isEmpty()) {
			saveMessages(request, msgs);
			return mapping.findForward("modify_title");
		}

		return makeForward(mapping.findForward("editsite"), sform.getSid());
	}

	/**
	 * ������վ��������
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	protected ActionForward doUpdateSite(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		SiteForm f_site = (SiteForm) form;
		super.validateClientId(request, f_site);
		ActionMessages msgs = new ActionMessages();
		// ��֤�������
		String friendlyName = super
				.autoFiltrate(null, f_site.getFriendlyName());
		do {
			if (StringUtils.isEmpty(friendlyName)) {
				msgs.add("friendlyName", new ActionMessage(
						"error.site_friendlyName_empty"));
				break;
			}
			// �ж���վ���Ƿ����
			SiteBean site = super.getSiteBean(request);
			if (!StringUtils.equals(site.getFriendlyName(), friendlyName)
					&& SiteDAO.getSiteByFriendlyName(friendlyName) != null) {
				msgs.add("friendlyName", new ActionMessage(
						"error.site_friendlyName_exists"));
				break;
			}
			if (site != null) {
				if (StringUtils.isNotEmpty(f_site.getDetail())) {
					String dt = super.autoFiltrate(site, StringUtils
							.extractText(f_site.getDetail()));
					site.setDetail(StringUtils.abbreviate(dt, 250));
				} else
					site.setDetail(null);

				if (!StringUtils.equals(site.getFriendlyName(), friendlyName))
					site.setFriendlyName(friendlyName);

				if (StringUtils.isNotEmpty(f_site.getIcpNumber())) {
					site.setIcpNumber(DLOGSecurityManager.IllegalGlossary
							.deleteIllegalWord(f_site.getIcpNumber()));
				} else
					site.setIcpNumber(null);
				site.setLastTime(new Date());
				if (StringUtils.isNotEmpty(f_site.getTitle()))
					site.setTitle(super.autoFiltrate(site, f_site.getTitle()));
				else
					site.setTitle(site.getFriendlyName());

				if (StringUtils.isNotEmpty(f_site.getUrl()))
					if (f_site.getUrl().toLowerCase().startsWith("http://"))
						site.setUrl(f_site.getUrl().substring(7));
					else
						site.setUrl(f_site.getUrl());
				else
					site.setUrl(null);

				try {
					SiteDAO.updateSite(site);
					msgs.add("site", new ActionMessage("site.updated"));
				} catch (Exception e) {
					context().log("Update site failed.", e);
					msgs.add("site", new ActionMessage("error.database", e
							.getMessage()));
				}
			}
			break;
		} while (true);

		if (!msgs.isEmpty())
			saveMessages(request, msgs);

		return mapping.getInputForward();
	}

	/**
	 * ������վ�Ű���ʽ�Լ�LOGO
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	protected ActionForward doUpdateStyle(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		SiteForm f_site = (SiteForm) form;
		super.validateClientId(request, f_site);
		ActionMessages msgs = new ActionMessages();

		SiteBean site = super.getSiteBean(request);
		if (site != null) {
			if (StringUtils.isNotEmpty(f_site.getLayoutFile()))
				site.getStyle().setLayout(f_site.getLayoutFile());
			else
				site.getStyle().setLayout("1");

			if (StringUtils.isNotEmpty(f_site.getCssFile())
					&& !StringUtils.equals(f_site.getCssFile(), site.getStyle()
							.getCss()))
				site.getStyle().setCss(f_site.getCssFile());
			else
				site.getStyle().setCss("main.css");

			// TODO: ����LOGO

			site.setLastTime(new Date());
			try {
				SiteDAO.updateSite(site);
			} catch (Exception e) {
				context().log("Update site's style failed.", e);
				msgs.add("site", new ActionMessage("error.database", e
						.getMessage()));
			}
		}

		if (!msgs.isEmpty()) {
			saveMessages(request, msgs);
			return mapping.findForward("style-setting");
		}

		return makeForward(mapping.findForward("settings"), f_site.getSid());
	}

	/**
	 * ������վ�Ĺ���
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	protected ActionForward doUpdateFuncs(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		SiteForm f_site = (SiteForm) form;
		super.validateClientId(request, f_site);
		ActionMessages msgs = new ActionMessages();

		SiteBean site = super.getSiteBean(request);
		if (site != null) {
			// TODO: ���Ƴ���
			// Diary
			if (StringUtils.isEmpty(f_site.getDiaryName()))
				site.setDiary(null);
			else
				site.setDiary(super.autoFiltrate(site, f_site.getDiaryName()));
			site
					.getFunctionStatus()
					.setDiary(
							(f_site.getStatusDiary() == 1) ? FunctionStatus.STATUS_NORMAL
									: FunctionStatus.STATUS_CLOSED);
			// Photo
			if (StringUtils.isEmpty(f_site.getPhotoName()))
				site.setPhoto(null);
			else
				site.setPhoto(super.autoFiltrate(site, f_site.getPhotoName()));
			site
					.getFunctionStatus()
					.setPhoto(
							(f_site.getStatusPhoto() == 1) ? FunctionStatus.STATUS_NORMAL
									: FunctionStatus.STATUS_CLOSED);
			// Music
			if (StringUtils.isEmpty(f_site.getMusicName()))
				site.setMusic(null);
			else
				site.setMusic(super.autoFiltrate(site, f_site.getMusicName()));
			site
					.getFunctionStatus()
					.setMusic(
							(f_site.getStatusMusic() == 1) ? FunctionStatus.STATUS_NORMAL
									: FunctionStatus.STATUS_CLOSED);
			// BBS
			if (StringUtils.isEmpty(f_site.getForumName()))
				site.setForum(null);
			else
				site.setForum(super.autoFiltrate(site, f_site.getForumName()));
			site
					.getFunctionStatus()
					.setForum(
							(f_site.getStatusForum() == 1) ? FunctionStatus.STATUS_NORMAL
									: FunctionStatus.STATUS_CLOSED);
			// Guestbook
			if (StringUtils.isEmpty(f_site.getGuestbookName()))
				site.setGuestbook(null);
			else
				site.setGuestbook(super.autoFiltrate(site, f_site
						.getGuestbookName()));
			site
					.getFunctionStatus()
					.setGuestbook(
							(f_site.getStatusGuestbook() == 1) ? FunctionStatus.STATUS_NORMAL
									: FunctionStatus.STATUS_CLOSED);
			// Friend
			if (StringUtils.isEmpty(f_site.getFriendName()))
				site.setFriend(null);
			else
				site
						.setFriend(super.autoFiltrate(site, f_site
								.getFriendName()));
			site
					.getFunctionStatus()
					.setFriend(
							(f_site.getStatusFriend() == 1) ? FunctionStatus.STATUS_NORMAL
									: FunctionStatus.STATUS_CLOSED);

			site.setLastTime(new Date());
			try {
				SiteDAO.updateSite(site);
			} catch (Exception e) {
				context().log("Update site's functions failed.", e);
				msgs.add("site", new ActionMessage("error.database", e
						.getMessage()));
			}
		}

		if (!msgs.isEmpty()) {
			saveMessages(request, msgs);
			return mapping.findForward("funcs-setting");
		}

		return makeForward(mapping.findForward("settings"), f_site.getSid());
	}

	// ====================DLOG 3.5=====================
	/**
	 * ������վ�Ű���ʽ�Լ�LOGO[��]
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	protected ActionForward doUpdateStyle_(ActionMapping mapping,
			ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		SiteForm f_site = (SiteForm) form;
		
		if(f_site.getType()==1)
		{
			// �ж��û��Ƿ��¼
			SessionUserObject loginUser = super.getLoginUser(request, response,
					false);
			if(loginUser==null)
				return msgbox(mapping, form, request, response, "���ȵ�¼",f_site.getFromPage());
			if(loginUser.getRole()!=UserBean.ROLE_VIP)
				return msgbox(mapping, form, request, response, "�Բ���,������VIP�û�",f_site.getFromPage());
		}
		SiteBean bean=SiteDAO.getSiteByID(f_site.getId());
		bean.setCss(f_site.getCssFile());
		bean.setLayout(f_site.getLayoutFile());
		SiteDAO.updateSite(bean);
		return msgbox(mapping, form, request, response, "���óɹ�",f_site.getFromPage());

	}
}
