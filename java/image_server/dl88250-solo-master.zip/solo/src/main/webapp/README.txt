A Java blogging system, feel free to create your or your team own blog.

Project home: https://github.com/b3log/solo
Request features/Report bugs: https://github.com/b3log/solo/issues/new

* QQ Qun: 13139268
* User Guide: https://github.com/b3log/solo/wiki/Pre_installation
* Dev Guide: https://github.com/b3log/solo/wiki/Pre_dev
  * Skin Dev Guide: https://github.com/b3log/solo/wiki/Develop_steps
  * Plugin Dev Guide: https://docs.google.com/document/pub?id=15H7Q3EBo-44v61Xp_epiYY7vK_gPJLkQaT7T1gkE64w&pli=1

====
B3log Index: http://b3log.org

B3log Team: https://github.com/b3log/solo/wiki/About_us
Join B3log Team: https://github.com/b3log/solo/wiki/Join_us
====

平等，自由，奔放
Equality, Freedom, Passion

;-)
