(function($){
	$.opp = function() {
		console.log('类封装...');
	}
	$.fn.add = function() {
		console.log('对象封装...');
	}
})(jQuery)

 