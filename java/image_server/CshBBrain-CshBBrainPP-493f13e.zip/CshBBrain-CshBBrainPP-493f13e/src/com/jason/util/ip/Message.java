package com.jason.util.ip;

public interface Message {
	String bad_ip_file="IP地址库文件错误";
	String unknown_country = "";
	String unknown_area = "";
}
