package com.djk.springdemo.mapper1;

import com.djk.springdemo.bean.Email;

public interface TestMapper1 {
	Email findemail();
}
