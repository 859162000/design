package com.chavin.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.chavin.cache.EhcacheUtil;
import com.chavin.vo.User;

public class UserDao {

	public static List<User> getUserList(){
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		List<User> userList = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/cache";
			conn = DriverManager.getConnection(url, "root", "root");
			String sql = "select * from user";
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			User user;
			userList = new ArrayList<User>(); 
			while (rs.next()) {
				user = new User();
				user.setId(rs.getInt(1));
				user.setName(rs.getString(2));
				user.setAge(rs.getInt(3));
				user.setSex(rs.getString(4));
				user.setAddress(rs.getString(5));
				user.setDeleted(rs.getInt(6));
				userList.add(user);
			}
			if(!userList.isEmpty()){
				EhcacheUtil uEhcacheUtil = EhcacheUtil.getInstance();
				userList.add(null);
				userList.add(null);
				uEhcacheUtil.putElement("userListCache", "userList", userList);
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally{
			CloseAll(pst,conn,rs);
		}
		return userList;
	}
	
	public static int update(int deleted, String sql){
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		List<User> userList = null;
		int m = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/cache";
			conn = DriverManager.getConnection(url, "root", "root");
			pst = conn.prepareStatement("update user set deleted = ? where " + sql);
			pst.setInt(1, deleted);
			m = pst.executeUpdate();
			//修改后重新设置缓存
			if(m > 0){
				pst = conn.prepareStatement("select * from user");
				rs = pst.executeQuery();
				User user;
				userList = new ArrayList<User>(); 
				while (rs.next()) {
					user = new User();
					user.setId(rs.getInt(1));
					user.setName(rs.getString(2));
					user.setAge(rs.getInt(3));
					user.setSex(rs.getString(4));
					user.setAddress(rs.getString(5));
					user.setDeleted(rs.getInt(6));
					userList.add(user);
				}
				if(!userList.isEmpty()){
					EhcacheUtil uEhcacheUtil = EhcacheUtil.getInstance();
					uEhcacheUtil.removeAllElement("userListCache");
					uEhcacheUtil.putElement("userListCache", "userList", userList);
					System.out.println("缓存已更新");
				}
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally{
			CloseAll(pst,conn,rs);
		}
		return m;
	}

	
	
	private static void CloseAll(PreparedStatement pst, Connection connection, ResultSet rs) {
		try {
			if (rs != null) {
				rs.close();
			}
			if(pst != null){
				pst.close();
			}
			if(connection != null){
				connection.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		//System.out.println(getUserList().size());
		//String sql = "update user set deleted = 0";
		System.out.println(update(1," id > 20"));
	}
	
}
