package com.chavin.cache;

import java.net.URL;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

/**
 * Ehcache工具类
 * EhcacheUtil
 * 时间：2015年12月3日-下午3:13:27 
 * @version 1.0.0
 *
 */
public class EhcacheUtil {

	private static EhcacheUtil ehcacheUtil;
	private static CacheManager cacheManager;
	private Cache cache; 
	private Element element;
	
	private EhcacheUtil(){
		init();
	}
	
	/**
	 * 初始化cacheManager
	 * @exception 
	 * @since  1.0.0
	 */
	public void init(){
//		URL url = EhcacheUtil.class.getClass().getResource("/ehcache.xml");
//		cacheManager = CacheManager.create(url);
		cacheManager = CacheManager.create();
	}
	
	/**
	 * 单例模式 
	 * @return EhcacheUtil<br/>
	 * @exception 
	 * @since  1.0.0
	 */
	public static EhcacheUtil getInstance(){
		if(ehcacheUtil == null){
			ehcacheUtil = new EhcacheUtil();
		}
		return ehcacheUtil;
	}
    
    /**
     * 检查cachemanager是否初始化了
     */
    public void checkCacheManager(){
    	if(cacheManager == null){
    		throw new IllegalArgumentException("CacheManage未初始化！");  
    	}
    }
    
	/**
	 * 添加缓存对象
	 * @param cacheName
	 * @param key element的key
	 * @param value Element的value<br/>
	 * @exception 
	 * @since  1.0.0
	 */
	public void putElement(String cacheName, Object key, Object value){
		cache = getCache(cacheName);
		element = new Element(key,value);
		cache.put(element);
	}
	
	/**
	 * 
	 * 获取缓存对象
	 * @param cacheName
	 * @param key Element对象的KEY
	 */
	public Object getElement(String cacheName, Object key){
		Cache cache = getCache(cacheName);
		Element element = cache.get(key);
		
		return element == null ? null : element.getObjectValue();
	}
	
	/**
	 * 从name为cacheName的cache中删除指定key的对象
	 * @param cacheName
	 * @param key 移除Element
	 */
	public void removeElement(String cacheName, Object key){
		Cache cache = getCache(cacheName);
		cache.remove(key);
	}
	
	/**
	 * 移除所有的缓存元素
	 * @param cacheName 
	 * @exception 
	 */
	public void removeAllElement(String cacheName){
		Cache cache = getCache(cacheName);
		cache.removeAll();
	}
	
	/**
	 * 通过名称获取Cache 
	 * @param cacheName
	 * @return Cache
	 */
	public Cache getCache(String cacheName){
		checkCacheManager();
		cache = cacheManager.getCache(cacheName);
		if(cache == null){
			throw new IllegalArgumentException("请先配置name为" + cacheName + "的cache");
		}
		return cache;
	}

	/**
	 * 移除指定的cache
	 * @param cacheName void<br/>
	 * @exception 
	 */
	public void removeCache(String cacheName){
		cache = getCache(cacheName);
		cacheManager.removeCache(cacheName);
	}
	
	
	public static void main(String[] args) {
		EhcacheUtil ehcacheUtil = EhcacheUtil.getInstance();
		ehcacheUtil.putElement("cache", "name", "张三");
		ehcacheUtil.putElement("cache", "age", "15");
		ehcacheUtil.putElement("cache", "address", "广州");
		System.out.println(ehcacheUtil.getElement("cache", "age"));
	}
}
