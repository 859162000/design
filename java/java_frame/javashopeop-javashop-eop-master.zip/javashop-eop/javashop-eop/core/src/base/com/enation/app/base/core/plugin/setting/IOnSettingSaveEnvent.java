package com.enation.app.base.core.plugin.setting;

/**
 * 设置保存事件
 * @author kingapex
 *
 */
public interface IOnSettingSaveEnvent {
	
	
	public void onSave();
	
}
